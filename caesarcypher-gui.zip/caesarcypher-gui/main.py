import tkinter as tk

root = tk.Tk()
root.title("Caesar Cipher Tool")
root.geometry("550x450")
root.configure(bg="#f4f4f4")


# ---------------- FUNCTIONS ---------------- #

def encrypt():
    text = message_entry.get()
    shift = int(shift_entry.get())

    result = ""

    for char in text:
        if char.isalpha():

            if char.isupper():
                result += chr((ord(char)-65+shift)%26+65)

            else:
                result += chr((ord(char)-97+shift)%26+97)

        else:
            result += char

    result_label.config(text="Result: " + result)


def decrypt():
    text = message_entry.get()
    shift = int(shift_entry.get())

    result = ""

    for char in text:
        if char.isalpha():

            if char.isupper():
                result += chr((ord(char)-65-shift)%26+65)

            else:
                result += chr((ord(char)-97-shift)%26+97)

        else:
            result += char

    result_label.config(text="Result: " + result)


def clear_fields():
    message_entry.delete(0, tk.END)
    shift_entry.delete(0, tk.END)
    result_label.config(text="Result:")


def copy_result():
    text = result_label.cget("text").replace("Result: ", "")
    root.clipboard_clear()
    root.clipboard_append(text)


# ---------------- TITLE ---------------- #

title = tk.Label(
    root,
    text="Caesar Cipher Tool",
    font=("Segoe UI",18,"bold"),
    bg="#f4f4f4"
)
title.pack(pady=10)


# ---------------- MESSAGE ---------------- #

message_label = tk.Label(root, text="Message:", bg="#f4f4f4")
message_label.pack()

message_entry = tk.Entry(root, width=40)
message_entry.pack(pady=5)


# ---------------- SHIFT ---------------- #

shift_label = tk.Label(root, text="Shift Value:", bg="#f4f4f4")
shift_label.pack()

shift_entry = tk.Entry(root, width=10)
shift_entry.pack(pady=5)


# ---------------- BUTTONS ---------------- #

button_frame = tk.Frame(root, bg="#f4f4f4")
button_frame.pack(pady=10)

encrypt_btn = tk.Button(
    button_frame,
    text="Encrypt",
    width=15,
    command=encrypt
)
encrypt_btn.grid(row=0,column=0,padx=5)

decrypt_btn = tk.Button(
    button_frame,
    text="Decrypt",
    width=15,
    command=decrypt
)
decrypt_btn.grid(row=0,column=1,padx=5)


# ---------------- RESULT ---------------- #

result_label = tk.Label(
    root,
    text="Result:",
    font=("Segoe UI",12,"bold"),
    bg="#f4f4f4"
)
result_label.pack(pady=15)


# ---------------- EXTRA BUTTONS ---------------- #

clear_btn = tk.Button(
    root,
    text="Clear",
    width=15,
    command=clear_fields
)
clear_btn.pack(pady=5)

copy_btn = tk.Button(
    root,
    text="Copy Result",
    width=15,
    command=copy_result
)
copy_btn.pack()


root.mainloop()